/*
function mouseHoverOn() {
    document.getElementById("mouse").style.color = "#f00";
    document.getElementsByTagName("strong").style.color = "#f00";
}

function mouseHoverOff() {
    document.getElementById("mouse").style.color = "#fff";
    document.getElementsByTagName("strong").style.color = "#fff";

}
*/